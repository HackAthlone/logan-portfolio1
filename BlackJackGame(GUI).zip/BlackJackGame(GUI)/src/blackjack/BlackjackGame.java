package blackjack;

public class BlackjackGame {
    private Deck deck;
    private Hand playerHand;
    private Hand dealerHand;
    private int playerBalance;
    private int currentBet;

    public BlackjackGame() {
        deck = new Deck();
        playerHand = new Hand();
        dealerHand = new Hand();
        playerBalance = 100; // Starting balance
    }

    public void startNewRound(int bet) {
        if (bet > playerBalance) {
            throw new IllegalArgumentException("Insufficient funds!");
        }
        currentBet = bet;
        playerBalance -= bet;

        // Reset hands
        playerHand = new Hand();
        dealerHand = new Hand();

        // Deal initial cards
        playerHand.addCard(deck.dealCard());
        playerHand.addCard(deck.dealCard());
        dealerHand.addCard(deck.dealCard());
        dealerHand.addCard(deck.dealCard());
    }

    public Hand getPlayerHand() {
        return playerHand;
    }

    public Hand getDealerHand() {
        return dealerHand;
    }

    public Card playerHit() {
        Card card = deck.dealCard();
        playerHand.addCard(card);
        return card;
    }

    public void dealerTurn() {
        while (dealerHand.getTotalValue() < 17) {
            dealerHand.addCard(deck.dealCard());
        }
    }

    public String getGameResult() {
        int playerTotal = playerHand.getTotalValue();
        int dealerTotal = dealerHand.getTotalValue();

        if (playerTotal > 21) {
            return "Player busts! Dealer wins.";
        } else if (dealerTotal > 21) {
            playerBalance += currentBet * 2;
            return "Dealer busts! Player wins.";
        } else if (playerTotal > dealerTotal) {
            playerBalance += currentBet * 2;
            return "Player wins!";
        } else if (dealerTotal > playerTotal) {
            return "Dealer wins!";
        } else {
            playerBalance += currentBet; // Return the bet on a tie
            return "It's a tie!";
        }
    }

    public int getPlayerBalance() {
        return playerBalance;
    }

    public boolean isGameOver() {
        return playerBalance <= 0;
    }
    public Card dealerHit() {
        Card card = deck.dealCard();
        dealerHand.addCard(card);
        return card;
    }

}

