package blackjack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlackjackGUI extends JFrame {
    private BlackjackGame game;
    private JButton hitButton, standButton, betButton, cashOutButton;
    private JTextField betInput;
    private JLabel balanceLabel, playerTotalLabel, dealerTotalLabel;
    private JPanel dealerPanel, playerPanel;
    private ImageIcon cardBackImage;
    private Map<String, ImageIcon> cardImages;
    private boolean dealerReveal = false; // Track when dealer's card should be revealed

    public BlackjackGUI() {
        setTitle("♠️ Blackjack Casino ♠️");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        game = new BlackjackGame();
        loadCardImages(); // Load card images from assets

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(34, 139, 34)); // Green felt background

        // Balance & Bet Panel
        JPanel betPanel = new JPanel();
        betPanel.setBackground(new Color(0, 100, 0));
        balanceLabel = new JLabel("💰 Balance: $" + game.getPlayerBalance());
        balanceLabel.setForeground(Color.ORANGE);
        balanceLabel.setFont(new Font("Serif", Font.BOLD, 20));

        betInput = new JTextField(5);
        betButton = createCasinoButton("🎲 Place Bet");

        betPanel.add(new JLabel("💵 Bet: "));
        betPanel.add(betInput);
        betPanel.add(betButton);
        betPanel.add(balanceLabel);

        // Card Display Panel
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new GridLayout(2, 1));
        cardPanel.setBackground(new Color(34, 139, 34));

        dealerPanel = new JPanel();
        dealerPanel.setBackground(new Color(34, 139, 34));
        dealerPanel.setBorder(BorderFactory.createTitledBorder("Dealer"));

        dealerTotalLabel = new JLabel("Dealer Total: ?");
        dealerTotalLabel.setForeground(Color.WHITE);
        dealerTotalLabel.setFont(new Font("Serif", Font.BOLD, 18));

        playerPanel = new JPanel();
        playerPanel.setBackground(new Color(34, 139, 34));
        playerPanel.setBorder(BorderFactory.createTitledBorder("Player"));

        playerTotalLabel = new JLabel("Player Total: 0");
        playerTotalLabel.setForeground(Color.WHITE);
        playerTotalLabel.setFont(new Font("Serif", Font.BOLD, 18));

        JPanel dealerInfoPanel = new JPanel();
        dealerInfoPanel.setBackground(new Color(34, 139, 34));
        dealerInfoPanel.add(dealerTotalLabel);

        JPanel playerInfoPanel = new JPanel();
        playerInfoPanel.setBackground(new Color(34, 139, 34));
        playerInfoPanel.add(playerTotalLabel);

        cardPanel.add(dealerInfoPanel);
        cardPanel.add(dealerPanel);
        cardPanel.add(playerInfoPanel);
        cardPanel.add(playerPanel);

        // Bottom Panel (Buttons)
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(0, 100, 0));

        hitButton = createCasinoButton("✋ Hit");
        standButton = createCasinoButton("🏁 Stand");
        cashOutButton = createCasinoButton("💰 Cash Out");

        buttonPanel.add(hitButton);
        buttonPanel.add(standButton);
        buttonPanel.add(cashOutButton);

        hitButton.setEnabled(false);
        standButton.setEnabled(false);
        cashOutButton.setEnabled(false);

        // Add to Main Frame
        mainPanel.add(betPanel, BorderLayout.NORTH);
        mainPanel.add(cardPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Button Actions
        betButton.addActionListener(e -> placeBet());
        hitButton.addActionListener(e -> playerHit());
        standButton.addActionListener(e -> playerStand());
        cashOutButton.addActionListener(e -> cashOut());

        setVisible(true);
    }

    private void placeBet() {
        try {
            int bet = Integer.parseInt(betInput.getText());
            if (bet <= 0) {
                JOptionPane.showMessageDialog(this, "Bet must be greater than zero.");
                return;
            }
            game.startNewRound(bet);
            dealerReveal = false; // Reset dealer's hidden card
            updateCards();
            updateBalanceLabel();

            hitButton.setEnabled(true);
            standButton.setEnabled(true);
            cashOutButton.setEnabled(true);
            betButton.setEnabled(false);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid bet amount.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void playerHit() {
        game.playerHit();
        updateCards();

        if (game.getPlayerHand().getTotalValue() > 21) {
            JOptionPane.showMessageDialog(this, "Player busts! Dealer wins.");
            endRound();
        }
    }
    
    private void playerStand() {
        dealerReveal = true; // Reveal dealer's first card
        hitButton.setEnabled(false);
        standButton.setEnabled(false);

        Timer timer = new Timer(1000, new ActionListener() { // 1-second delay
            @Override
            public void actionPerformed(ActionEvent e) {
                if (game.getDealerHand().getTotalValue() < 17) {
                    Card newCard = game.dealerHit(); // Dealer draws one card
                    updateCards(); // Refresh UI
                } else {
                    ((Timer) e.getSource()).stop(); // Stop when dealer is done
                    JOptionPane.showMessageDialog(null, game.getGameResult());
                    endRound();
                }
            }
        });

        timer.start(); // Start timer
    }


    private void cashOut() {
        JOptionPane.showMessageDialog(this, "You cashed out with $" + game.getPlayerBalance());
        System.exit(0);
    }

    private void endRound() {
        hitButton.setEnabled(false);
        standButton.setEnabled(false);
        betButton.setEnabled(true);
        updateBalanceLabel();

        if (game.isGameOver()) {
            JOptionPane.showMessageDialog(this, "Game Over! You ran out of money.");
            System.exit(0);
        }
    }
    private void updateBalanceLabel() {
        balanceLabel.setText("💰 Balance: $" + game.getPlayerBalance());
    }


    private void updateCards() {
        dealerPanel.removeAll();
        playerPanel.removeAll();

        // Dealer Cards
        for (int i = 0; i < game.getDealerHand().getCards().size(); i++) {
            JLabel cardLabel;
            if (i == 0 && !dealerReveal) {
                cardLabel = new JLabel(cardBackImage); // First card hidden
            } else {
                cardLabel = createCardLabel(getCardImage(game.getDealerHand().getCards().get(i)));
            }
            dealerPanel.add(cardLabel);
        }

        dealerTotalLabel.setText("Dealer Total: " + (dealerReveal ? game.getDealerHand().getTotalValue() : "?"));

        // Player Cards
        for (Card card : game.getPlayerHand().getCards()) {
            JLabel cardLabel = createCardLabel(getCardImage(card));
            playerPanel.add(cardLabel);
        }

        playerTotalLabel.setText("Player Total: " + game.getPlayerHand().getTotalValue());

        dealerPanel.revalidate();
        dealerPanel.repaint();
        playerPanel.revalidate();
        playerPanel.repaint();
    }

    private JLabel createCardLabel(ImageIcon cardImage) {
        JLabel label = new JLabel(cardImage);
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        return label;
    }

    private ImageIcon getCardImage(Card card) {
        return cardImages.getOrDefault(card.toString(), cardBackImage);
    }

    private JButton createCasinoButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.ORANGE);
        button.setFont(new Font("SansSerif", Font.BOLD, 16));
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BlackjackGUI::new);
    }
    private void loadCardImages() {
        cardImages = new HashMap<>();
        cardBackImage = resizeImage("assets/cards/back.png", 80, 120); // Ensure the path is correct

        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};

        for (String suit : suits) {
            for (String rank : ranks) {
                String filename = "assets/cards/" + rank + "_of_" + suit + ".png";
                cardImages.put(rank + " of " + suit, resizeImage(filename, 80, 120));
            }
        }
    }

    /**
     * Helper method to resize card images.
     */
    private ImageIcon resizeImage(String path, int width, int height) {
        ImageIcon icon = new ImageIcon(path);
        Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

}
